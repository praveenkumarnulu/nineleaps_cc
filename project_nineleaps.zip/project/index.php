<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>NineLeaps </title>


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">


      <link rel="stylesheet" href="css/index_style.css">


</head>

<body>
  <h1>NineLeaps Coding Challenge</h1>
  <h2>An Application software for the HR to store all the employee data</h2>
  <div class="main">
    <div class="sub-main">
      <a href="table_view.php" class="button-one" role="button">Table View</a>
    </div>
    <div class="sub-main">
            <a href="list_view.php" class="button-two" role="button">List View</a>
    </div>
    <div class="sub-main">
      <button class="button-three">Click Me</button>
    </div>

  </div>


</body>
</html>
