<?php

require_once('dbconfig.php');


 if (isset($_GET['id']))
{
          // Instructions if $_POST['value'] exist
  $emp_id = $_GET['id'];
}


$SelSql = "SELECT name,designation,manager_id FROM `employee` WHERE emp_id=$emp_id";

$res = mysqli_query($connection, $SelSql);

$r = mysqli_fetch_assoc($res);


if(isset($_POST) & !empty($_POST)){
    // $name = $_POST['name'];
    $designation = $_POST['designation'];
    if(isset($_POST['manager_id'])){
    $manager_id = $_POST['manager_id'];


if(isset($_POST['name'])){
$name = $_POST['name'];

}
// if(isset(['designation'])){
//   $designation = $_POST['designation'];
// }


$UpdateSql = "UPDATE `employee` SET `name`='$name',`designation`='$designation',`manager_id`='$manager_id' WHERE emp_id = $emp_id";
$res = mysqli_query($connection, $UpdateSql);

if($res){
    header('location: table_view.php');
}else{
    header('location: form.php');
    $fmsg = "Failed to update data.";
}





}




}?>



<!DOCTYPE html>
<html>
<head>
    <title>Edit the employee details</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

<link rel="stylesheet" href="style_form.css" >

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <div class="row">
        <form method="post" class="form-horizontal col-md-6 col-md-offset-3" id="contact_form">
        <h2>UPDATE Employee Details</h2>
            <div class="form-group">
                <label for="input1" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                  <input type="text" name="name"  class="form-control" id="input1" value="<?php echo $r['name']; ?>" placeholder="Name" />
                </div>
            </div>

            <div class="form-group">
                <label for="input1" class="col-sm-2 control-label">Designation</label>
                <div class="col-sm-10">
                  <input type="text" name="designation"  class="form-control" id="input1" value="<?php echo $r['designation']; ?>" placeholder="Designation" />
                </div>
            </div>

            <div class="form-group">
            <label for="input1" class="col-sm-2 control-label">Manager</label>
            <div class="col-sm-10">
                <select name="managerid" class="form-control">
                    <option>Please Select manager</option>
                    <option value="1"   <?php if($r['manager_id'] == 1){ echo "selected";} ?>  >1</option>
                    <option value="2" <?php if($r['manager_id'] == 2){ echo "selected";} ?> >2</option>

                </select>
            </div>
            </div>
            <input type="submit" class="btn btn-primary col-md-2 col-md-offset-10" value="submit" />


<?php
          if(isset($fmsg)){
  ?>
  <h3>"<?php echo $fmsg; ?>"</h3>
  <?php
}
?>

        </form>
    </div>
</div>

    <script  src="js/index_form.js"></script>
</body>
</html>