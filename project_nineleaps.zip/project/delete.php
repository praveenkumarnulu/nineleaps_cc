<?php
require_once('dbconfig.php');
$emp_id = $_GET['id'];
$DelSql = "DELETE FROM employee WHERE emp_id=$emp_id";
$res = mysqli_query($connection, $DelSql);
if($res){
    header('location: table_view.php');
}else{
    echo "Failed to delete";
}
?>