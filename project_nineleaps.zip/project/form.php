<?php
require_once ('dbconfig.php');

if(isset($_POST) & !empty($_POST)){
  $name = $_POST['name'];
  $designation = $_POST['designation'];
  if (isset($_POST['managerid']))
{
          // Instructions if $_POST['value'] exist
  $managerid = $_POST['managerid'];
}

$CreateSql = "INSERT INTO `employee`( `name`, `designation`, `manager_id`) VALUES ('$name','$designation', $managerid);";

$res = mysqli_query($connection, $CreateSql) or die(mysqli_error($connection));


  if($res){
    $smsg = "Successfully inserted data, Insert New data.";
  }else{
    $fmsg = "Data not inserted, please try again later.";
  }

  }

  $selectsql = "SELECT `emp_id`, `name` FROM `employee` ORDER BY emp_id";
  $res1 = mysqli_query($connection, $selectsql) or die(mysqli_error($connection));



?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>NineLeapsCC</title>
  <script src="https://s.codepen.io/assets/libs/modernizr.js" type="text/javascript"></script>



  <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css'>
<link rel='stylesheet prefetch' href='http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.0/css/bootstrapValidator.min.css'>

      <link rel="stylesheet" href="css/style_form.css">


</head>

<body>
  <div class="container">



    <form class="well form-horizontal" action=" " method="post"  id="contact_form">
<fieldset>

<!-- Form Name -->
<legend><a href="index.php" class="btn btn-info" role="button">Home</a>
 &nbsp; HR Application for employee data</legend>


<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label">Full Name *</label>
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="name" placeholder="Name" class="form-control"  type="text">
    </div>
  </div>
</div>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label" >Designation *</label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
   <select name="designation" class="form-control selectpicker" >
 <option value="" >Please Select Designation</option>
 <option value="CEO" >CEO</option>
 <option value="COO" >COO</option>
 <option value="VP SALES" >VICE PRESIDENT(SALES)</option>
 <option value="VP MARKET" >VICE PRESIDENT MARKETING</option>
 <option value="HR HEAD" >HR HEAD</option>
 <option value="FIN HEAD" >FINANCIAL HEAD</option>
 <option value="CTO" >CTO</option>
 <option value="ACCOUNT MANAGER" >ACCOUNT MANAGER</option>
 <option value="BUSSINESS ANALYST" >BUSSINESS ANALYST</option>
 <option value="SCRUM MASTER" >SCRUM MASTER</option>
 <option value="QUALITY HEAD" >QUALITY HEAD</option>
 <option value="DEVELOPMENT HEAD" >DEVELOPMENT HEAD</option>
 <option value="SALES MANAGER" >SALES MANAGER</option>
 <option value="MARKETING MANAGER" >MARKETING MANAGER</option>
 <option value="RECRUITMENT MANAGER" >RECRUITMENT MANAGER</option>
 <option value="LD MANAGER" >L and D MANAGER</option>
 <option value="FACILITIES" >FACILITIES</option>
 <option value="SOLUTION ARCHITECT" >SOLUTION ARCHITECT</option>
 <option value="QUALITY MANAGER" >QUALITY MANAGER</option>
 <option value="DEVELOPER" >DEVELOPER</option>
 <option value="TESTER" >TESTER</option>
 <option value="MOBILE TESTER" >MOBILE TESTER</option>

</select>

  <!-- <input name="designation" placeholder="Designation" class="form-control"  type="text">
   -->  </div>
  </div>
</div>







<!-- Select Basic -->

<div class="form-group">
  <label class="col-md-4 control-label">Manager</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="managerid" class="form-control selectpicker" >
 <option value="null" >Please Select concerned manager</option>

<?php
while($r1 = mysqli_fetch_assoc($res1)){
?>

      <option value = "<?php echo $r1['emp_id']; ?>">  <?php echo $r1['name']; ?>     </option>
 <?php } ?>
    </select>

  </div>
</div>
</div>





<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
    <button type="submit" class="btn btn-warning" >Add <span class="glyphicon glyphicon-ok"></span></button>
  </div>
  <div class="col-md-0">
  <a href="table_view.php" class="btn btn-info" role="button">View Employee Details</a>
</div>
  </div>
<?php
if(isset($smsg)){
  ?>
  <h3>"<?php echo $smsg; ?>"</h3>
  <?php
}
?>



</fieldset>
</form>
</div>



    </div><!-- /.container -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>

    <script  src="js/index_form.js"></script>

</body>
</html>
