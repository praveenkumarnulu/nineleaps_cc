<?php
require_once('dbconfig.php');

?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Parent child vertical list menu</title>
  <link href='https://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">


      <link rel="stylesheet" href="css/list_style.css">


</head>

<body>
  <h1>List View</h1>
  <nav class="nav">
      <ul class=list>
            <li>
                <a href="#">ANCHAL</a> &nbsp; CEO
            </li>

      <ul class = list>
        <li>
          <a href="#">ANIKA</a> &nbsp; COO
        </li>

          <ul class =list>
          <?php

          $ReadSql = "SELECT name from employee where manager_id = 64";
          $res = mysqli_query($connection, $ReadSql);
          while($r = mysqli_fetch_assoc($res)){
          ?>
          <li>
            <a href="#"><?php echo $r['name'];?> </a>
          </li>
          <?php }?>
        </ul>





        <li>
          <a href="#">ASHLESHA</a> &nbsp; VP SALES
        </li>
        <li>
          <a href="#">BIRJU</a> &nbsp; VP MARKET
        </li>
        <li>
          <a href="#">DEVAK</a> &nbsp; HR HEAD
        </li>
        <li>
          <a href="#">PHANI</a> &nbsp; HR FINANCIAL
        </li>
        <li>
          <a href="#">SACHIT</a> &nbsp; CTO
        </li>
      </ul>
    </ul>
   </nav>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script  src="js/index.js"></script>

</body>
</html>
