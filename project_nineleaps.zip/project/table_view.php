<?php
require_once('dbconfig.php');

$ReadSql = "SELECT * from employee";
$res = mysqli_query($connection, $ReadSql);
?>


<!DOCTYPE html>
<html>
<head>
    <title>Table View</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >

<link rel="stylesheet" href="styles.css" >

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- jquesry for popup -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

</head>
<body>
<div class="container">
    <div class="row">
    <h2><a href="index.php">NineLeaps</a></h2>
    <a href="form.php" class="btn btn-info" role="button">Add New Member</a>
        <table class="table " border = "1">
        <thead>

            <tr>
                <th>Employee ID</th>
                <th>Name</th>
                <th>Designation</th>
                <th>Manager</th>
                <th>View</th>
            </tr>
        </thead>
        <tbody>
             <?php
                while($r = mysqli_fetch_assoc($res)){
                ?>
            <tr>
                <th scope="row"><?php echo $r['emp_id']; ?></th>
                <td><?php echo $r['name']; ?></td>
                <td><?php echo $r['designation']; ?></td>
                <td><?php echo $r['manager_id']?></td>

                <td>
                    <a href="update.php?id=<?php echo $r['emp_id']; ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                    <a href="delete.php?id=<?php echo $r['emp_id']; ?>"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a>
                </td>
            </tr>
<?php } ?>


        </tbody>
        </table>
    </div>
</div>
</body>
</html>